package com.projectnull.dao;

import com.projectnull.dto.ClinicDTO;
import com.projectnull.dto.ClinicDetailDTO;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import static com.projectnull.common.JDBCTemplate.close;

public class ClinicDAO {

    private Properties prop = new Properties();

    public ClinicDAO() {
        try {
            prop.loadFromXML(new FileInputStream("src/main/java/com/projectnull/mapper/hospital-query.xml"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /* ===================== Create ===================== */
    public int insertClinic(Connection con, ClinicDTO c) {
        PreparedStatement pstmt = null;
        int result = 0;
        String sql = prop.getProperty("insertClinic");

        try {
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, c.getClinicCode());
            pstmt.setInt(2, c.getDoctorCode());
            pstmt.setInt(3, c.getPatientCode());
            if (c.getPrescriptionCode() == null || c.getPrescriptionCode().isEmpty()) {
                pstmt.setNull(4, Types.VARCHAR);
            } else {
                pstmt.setString(4, c.getPrescriptionCode());
            }
            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            close(pstmt);
        }

        return result;
    }

    /* ===================== Read (기본 목록) ===================== */
    public List<ClinicDTO> selectAllClinics(Connection con) {
        PreparedStatement pstmt = null;
        ResultSet rset = null;

        List<ClinicDTO> list = new ArrayList<>();
        String sql = prop.getProperty("selectAllClinics");

        try {
            pstmt = con.prepareStatement(sql);
            rset = pstmt.executeQuery();

            while (rset.next()) {
                list.add(new ClinicDTO(
                        rset.getInt("clinic_code"),
                        rset.getInt("doctor_code"),
                        rset.getInt("patient_code"),
                        rset.getString("prescription_code")
                ));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            close(rset);
            close(pstmt);
        }

        return list;
    }

    /* ===================== Read (JOIN 전체) ===================== */
    public List<ClinicDetailDTO> selectAllClinicsDetail(Connection con) {
        PreparedStatement pstmt = null;
        ResultSet rset = null;

        List<ClinicDetailDTO> list = new ArrayList<>();
        String sql = prop.getProperty("selectAllClinicsDetail");

        try {
            pstmt = con.prepareStatement(sql);
            rset = pstmt.executeQuery();

            while (rset.next()) {
                ClinicDetailDTO d = new ClinicDetailDTO();
                d.setClinicCode(rset.getInt("clinic_code"));
                d.setDoctorCode(rset.getInt("doctor_code"));
                d.setDoctorName(rset.getString("doctor_name"));
                d.setSpecialty(rset.getString("specialty"));
                d.setClinicDay(rset.getString("clinic_day"));
                d.setClinicHours(rset.getString("clinic_hours"));

                d.setPatientCode(rset.getInt("patient_code"));
                d.setPatientName(rset.getString("patient_name"));
                d.setPatientNumber(rset.getString("patient_number"));
                d.setSymptoms(rset.getString("symptoms"));

                d.setPrescriptionCode(rset.getString("prescription_code"));
                d.setDiseaseName(rset.getString("disease_name"));

                Object ph = rset.getObject("pharmaceutical_code");
                d.setPharmaceuticalCode(ph == null ? null : ((Number) ph).intValue());
                d.setDrugName(rset.getString("drug_name"));
                d.setDosage(rset.getString("dosage"));

                list.add(d);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            close(rset);
            close(pstmt);
        }

        return list;
    }

    /* ===================== Read (JOIN 단건) ===================== */
    public ClinicDetailDTO selectClinicDetailByCode(Connection con, int clinicCode) {
        PreparedStatement pstmt = null;
        ResultSet rset = null;

        String sql = prop.getProperty("selectClinicDetailByCode");

        try {
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, clinicCode);
            rset = pstmt.executeQuery();

            if (rset.next()) {
                ClinicDetailDTO d = new ClinicDetailDTO();
                d.setClinicCode(rset.getInt("clinic_code"));
                d.setDoctorCode(rset.getInt("doctor_code"));
                d.setDoctorName(rset.getString("doctor_name"));
                d.setSpecialty(rset.getString("specialty"));
                d.setClinicDay(rset.getString("clinic_day"));
                d.setClinicHours(rset.getString("clinic_hours"));

                d.setPatientCode(rset.getInt("patient_code"));
                d.setPatientName(rset.getString("patient_name"));
                d.setPatientNumber(rset.getString("patient_number"));
                d.setSymptoms(rset.getString("symptoms"));

                d.setPrescriptionCode(rset.getString("prescription_code"));
                d.setDiseaseName(rset.getString("disease_name"));

                Object ph = rset.getObject("pharmaceutical_code");
                d.setPharmaceuticalCode(ph == null ? null : ((Number) ph).intValue());
                d.setDrugName(rset.getString("drug_name"));
                d.setDosage(rset.getString("dosage"));

                return d;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            close(rset);
            close(pstmt);
        }

        return null;
    }

    /* ===================== Update ===================== */
    public int updateClinic(Connection con, ClinicDTO c) {
        PreparedStatement pstmt = null;
        int result = 0;

        String sql = prop.getProperty("updateClinic");

        try {
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, c.getDoctorCode());
            pstmt.setInt(2, c.getPatientCode());
            if (c.getPrescriptionCode() == null || c.getPrescriptionCode().isEmpty()) {
                pstmt.setNull(3, Types.VARCHAR);
            } else {
                pstmt.setString(3, c.getPrescriptionCode());
            }
            pstmt.setInt(4, c.getClinicCode());

            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            close(pstmt);
        }

        return result;
    }

    /* ===================== Delete ===================== */
    public int deleteClinic(Connection con, int clinicCode) {
        PreparedStatement pstmt = null;
        int result = 0;

        String sql = prop.getProperty("deleteClinic");

        try {
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, clinicCode);
            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            close(pstmt);
        }

        return result;
    }

    public int deleteClinicAllInOne(Connection con, int clinicCode) {
        PreparedStatement pstmt = null;
        int result = 0;

        String sql = prop.getProperty("deleteClinicAllInOne");

        try {
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, clinicCode);
            int affected = pstmt.executeUpdate(); // 여러 테이블 합산된 삭제 건수
            result = affected > 0 ? 1 : 0;       // 해당 클리닉이 없으면 0
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            close(pstmt);
        }

        return result;
    }

    /* ===================== clinic_code 목록 조회 ===================== */
    public List<Integer> selectClinicCodes(Connection con) {
        PreparedStatement pstmt = null;
        ResultSet rset = null;

        List<Integer> codes = new ArrayList<Integer>();
        String sql = "SELECT clinic_code FROM clinic ORDER BY clinic_code";

        try {
            pstmt = con.prepareStatement(sql);
            rset = pstmt.executeQuery();

            while (rset.next()) {
                codes.add(rset.getInt("clinic_code"));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            close(rset);
            close(pstmt);
        }

        return codes;
    }
}
